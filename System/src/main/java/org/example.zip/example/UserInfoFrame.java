package org.example;

import javax.swing.*;
import java.awt.*;

public class UserInfoFrame extends JFrame{
	Font labelFont = new Font("仿宋", Font.PLAIN, 20);
	Font textFieldFont = new Font("仿宋", Font.PLAIN, 18);
	Font buttonFont = new Font("仿宋", Font.BOLD, 20);
	
	public UserInfoFrame(User user){
		setTitle("电商购物平台—用户信息界面");
		setSize(400, 500);
		setLocation(800, 200);
		init(user);
		setVisible(true);
	}
	void init(User user){
		Object[] title = {"用户名","姓名","角色","密码","性别","城市",};
		Object[][] userinfo = {{user.getId(),user.getName(),user.getType(),user.getPassword(),user.getSex(),user.getCity()}};

		JTable t = new JTable(userinfo, title);
		t.setFont(labelFont);
		add(new JScrollPane(t));
	}
}
