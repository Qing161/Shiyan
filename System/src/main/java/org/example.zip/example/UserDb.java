package org.example;

import java.sql.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserDb {
    // 数据库连接信息
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/YJYM";
    private static final String USER = "root";
    private static final String PASSWORD = "q3231423581";

    public boolean con(String username,String password) {
        Connection connection = null;
        try {
            // 加载JDBC驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
            // 创建连接
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT *FROM users;";
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                if (resultSet.getString("name").equals(username)) {
                    System.out.println("name=" + resultSet.getString("name"));
                    System.out.println("type=" + resultSet.getString("type"));
                    System.out.println("sex=" + resultSet.getString("sex"));
                    System.out.println("city=" + resultSet.getString("city"));
                    if(resultSet.getString("password").equals(password)){
                        return true;
                    }
                }
            }

        } catch (ClassNotFoundException e) {
            System.out.println("JDBC驱动未找到: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("数据库连接失败: " + e.getMessage());
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                    System.out.println("数据库连接已关闭。");
                }
            } catch (SQLException e) {
                System.out.println("关闭连接时出错: " + e.getMessage());
            }
        }
        return false;
    }

    public void add(String id, String name, String password, String type, char sex, String city){
        Connection connection = null;
        String insertSql = "INSERT INTO users (id, name, password, type, sex, city) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(insertSql)) {

            pstmt.setString(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, password);
            pstmt.setString(4, type);
            pstmt.setString(5, String.valueOf(sex));
            pstmt.setString(6, city);

            int rowsAffected = pstmt.executeUpdate(); // 使用 executeUpdate
            System.out.println("插入成功，受影响的行数: " + rowsAffected);

        } catch (SQLException e) {
            e.printStackTrace(); // 输出错误信息
        }
    }
    public ArrayList info(){
        Connection connection = null;
        ArrayList<User> userList = new ArrayList<>();
        try {
            // 加载JDBC驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
            // 创建连接
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT *FROM users;";
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery(sql);
            int i=0;
            while (resultSet.next()) {
                i++;
                String tid=resultSet.getString("id");
                String tname=resultSet.getString("name");
                String ttype=resultSet.getString("type");
                String ttsex=resultSet.getString("sex");
                char tsex=ttsex.charAt(0);
                String tcity=resultSet.getString("city");
                String tpassword=resultSet.getString("password");

                User u=new User(tid,tname,tpassword,ttype,tsex,tcity);
                userList.add(i,u);
            }
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC驱动未找到: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("数据库连接失败: " + e.getMessage());
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                    System.out.println("数据库连接已关闭。");
                }
            } catch (SQLException e) {
                System.out.println("关闭连接时出错: " + e.getMessage());
            }
        }
        return userList;
    }
}
