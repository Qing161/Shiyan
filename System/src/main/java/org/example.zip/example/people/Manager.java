package org.example.people;

public class Manager extends Person{
}
