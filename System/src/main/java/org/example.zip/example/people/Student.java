package org.example.people;

public class Student extends Person {
    public Student(String id,String name,int age,char sex){
        this.setId(id);
        this.setAge(age);
        this.setName(name);
        this.setSex(sex);
    }
}
