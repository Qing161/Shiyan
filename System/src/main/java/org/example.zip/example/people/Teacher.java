package org.example.people;

public class Teacher extends Person{
}
