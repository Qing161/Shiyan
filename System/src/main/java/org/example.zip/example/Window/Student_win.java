package org.example.Window;

import org.example.ConDb.Shiyan_db;
import org.example.Other_class.Shiyan_class;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

public class Student_win extends JFrame {
    JLabel l_name, l_category;
    JTextField t_name;
    JButton b_query;
    JTable table_book;
    JComboBox<String> c_category;

    Font labelFont = new Font("仿宋", Font.PLAIN, 20);
    Font textFieldFont = new Font("仿宋", Font.PLAIN, 18);
    Font buttonFont = new Font("仿宋", Font.BOLD, 20);


    private final JList<String> taskList = new JList<>();
    private final DefaultListModel<String> listModel = new DefaultListModel<>();
//    private final List<String> tasks = new ArrayList<>();

    Shiyan_db shiyan_db=new Shiyan_db();
    private final List<Shiyan_class> shiyan_list = shiyan_db.getShiyan_list();

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Student_win frame = new Student_win();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Student_win() {
        JLabel l1 = new JLabel("您好:" + "in_name", JLabel.LEFT);
        l1.setBounds(2, 2, 200, 20);
        l1.setFont(labelFont);
        JLabel l2 = new JLabel("来自于：" + "in_city", JLabel.RIGHT);
        l2.setBounds(655, 2, 300, 20);
        l2.setFont(labelFont);

        add(l1);
        add(l2);

        l_name = new JLabel("书籍名：", JLabel.LEFT);
        t_name = new JTextField();
        l_category = new JLabel("分类：", JLabel.RIGHT);
        c_category = new JComboBox<String>();
        c_category.addItem("工具类");
        c_category.addItem("小说类");
        b_query = new JButton("查询");

        l_name.setFont(labelFont);
        t_name.setFont(labelFont);
        l_category.setFont(labelFont);
        c_category.setFont(labelFont);
        b_query.setFont(labelFont);

        l_name.setBounds(2, 30, 600, 25);
        t_name.setBounds(70, 30, 170, 25);
        l_category.setBounds(675, 30, 80, 25);
        c_category.setBounds(755, 30, 150, 25);
        b_query.setBounds(270, 30, 100, 25);

        JPanel p=new JPanel();
        p.add(l_name);
        p.add(t_name);
        p.add(l_category);
        p.add(c_category);
        p.add(b_query);

        setTitle("简易任务管理器");
        setSize(960, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window

        taskList.setModel(listModel);
        taskList.setFont(labelFont);

        add(new JScrollPane(taskList), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1,4));
        JButton b_1=new JButton("上传实验报告");
        JButton b_2=new JButton("删除");
        JButton b_3=new JButton("查询");
        JButton b_4=new JButton("全部");

        b_1.addActionListener(this::ShangChuan);
        b_3.addActionListener(this::search);

        b_1.setFont(buttonFont);
        b_2.setFont(buttonFont);
        b_3.setFont(buttonFont);
        b_4.setFont(buttonFont);

        buttonPanel.add(b_1);
        buttonPanel.add(b_2);
        buttonPanel.add(b_3);
        buttonPanel.add(b_4);


        add(buttonPanel, BorderLayout.SOUTH);
        add(p, BorderLayout.NORTH);
        updateTaskList();
    }

//    private void addTask(ActionEvent e) {
//        String taskName = JOptionPane.showInputDialog(this, "请输入任务名称:");
//        if (taskName != null && !taskName.isEmpty()) {
////            tasks.add(taskName);
//            updateTaskList();
//        }
//    }

//    private void deleteSelectedTasks(ActionEvent e) {
//        int[] selectedIndices = taskList.getSelectedIndices();
//        for (int i : selectedIndices) {
////            tasks.remove(i);
//        }
//        updateTaskList();
//    }

        private void ShangChuan(ActionEvent e) {
        int[] selectedIndices = taskList.getSelectedIndices();
        for (int i : selectedIndices) {
//            tasks.remove(i);

        }
        updateTaskList();
    }

        private void search(ActionEvent e) {
        int[] selectedIndices = taskList.getSelectedIndices();
        for (int i : selectedIndices) {
            int j=0;
//            tasks.remove(i);
            for (Shiyan_class shiyan : shiyan_list) {

//                listModel.addElement(shiyan.getTitle()+"       "+shiyan.getEnd_time()+"截至！！！");
                if(j==i){
//                    JOptionPane.showMessageDialog(null, "你在查询"+shiyan.getTitle()+"!");
                    Student_each_shiyan s=new Student_each_shiyan(shiyan.getId());
                }
                j++;
            }

        }
//        updateTaskList();
    }

    private void updateTaskList() {
        listModel.clear();
        for (Shiyan_class shiyan : shiyan_list) {
            listModel.addElement(shiyan.getTitle()+"       "+shiyan.getEnd_time()+"截至！！！");
        }
    }
}