package org.example.Window;

import javax.swing.*;
import java.awt.event.*;

public class file {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JFileChooser Example");
        JButton button = new JButton("Select File");

        // 按钮点击事件  
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 创建文件选择器  
                JFileChooser fileChooser = new JFileChooser();
                int returnValue = fileChooser.showOpenDialog(frame); // 显示选择文件对话框  

                // 检查用户是否选择了文件  
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    // 获取选择的文件  
                    java.io.File selectedFile = fileChooser.getSelectedFile();
                    System.out.println("选择的文件: " + selectedFile.getAbsolutePath());
                }
            }
        });

        frame.add(button);
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
