package org.example.Window;

import org.example.ConDb.Shiyan_db;
import org.example.Other_class.Shiyan_class;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Student_each_shiyan extends JFrame {
    Font labelFont = new Font("仿宋", Font.PLAIN, 20);
    Font textFieldFont = new Font("仿宋", Font.PLAIN, 18);
    Font buttonFont = new Font("仿宋", Font.BOLD, 20);
    Shiyan_db shiyan_db=new Shiyan_db();
    private List<Shiyan_class> shiyan_list=shiyan_db.getShiyan_list();

    public Student_each_shiyan(String id){
        setTitle("实验详情");
        setSize(400, 500);
        setLocation(800, 200);
        init(id);
        setVisible(true);
    }

    private void init(String id) {
        this.setLayout(null);  //自定义布局

        JPanel p=new JPanel();
        p.setBackground(new Color(205,205,203));
        p.setBounds(0, 0, 400, 500);
////        p.setLocation(270,350);
        p.setLayout(new GridLayout(10,1));

        for(Shiyan_class k:shiyan_list){
            if(k.getId().equals(id)){
                System.out.println(k.getId());
                System.out.println(k.getTitle());
                System.out.println(k.getTeacher());
                System.out.println(k.getStart_time());
                System.out.println(k.getEnd_time());
                System.out.println(k.getCount_complete());

                JLabel l1=new JLabel("实验ID为："+k.getId());
                JLabel l2=new JLabel("实验名称为："+k.getTitle());
                JLabel l3=new JLabel("实验发布者为："+k.getTeacher());
                JLabel l4=new JLabel("实验发布时间为："+k.getStart_time());
                JLabel l5=new JLabel("实验截止时间为："+k.getEnd_time());
                JLabel l6=new JLabel("实验最终得分为：");

                l1.setFont(labelFont);
                l2.setFont(labelFont);
                l3.setFont(labelFont);
                l4.setFont(labelFont);
                l5.setFont(labelFont);
                l6.setFont(labelFont);



                p.add(l1);
                p.add(l2);
                p.add(l3);
                p.add(l4);
                p.add(l5);
                p.add(l6);
            }
        }
        this.add(p);
    }

    public static void main(String[] args) {
        Student_each_shiyan p=new Student_each_shiyan("123");
    }
}
