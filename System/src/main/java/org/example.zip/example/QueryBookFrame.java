package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class QueryBookFrame extends JFrame {
	JLabel l_name, l_category;
	JTextField t_name;
	JButton b_query;
	JTable table_book;
	JComboBox<String> c_category;

	Font labelFont = new Font("仿宋", Font.PLAIN, 20);
	Font textFieldFont = new Font("仿宋", Font.PLAIN, 18);
	Font buttonFont = new Font("仿宋", Font.BOLD, 20);

	public QueryBookFrame(String in_name,String in_city) {
		this.setTitle("电商购物平台——商品查询页面");
		this.setSize(960, 600);
		this.setLocationRelativeTo(null);
		init(in_name,in_city);
		this.setVisible(true);
		this.setResizable(false);
	}

	public void init(String in_name,String in_city) {
		this.setLayout(null);
		JLabel l1 = new JLabel("您好:" + in_name, JLabel.LEFT);
		l1.setBounds(2, 2, 200, 20);
		l1.setFont(labelFont);
		JLabel l2 = new JLabel("来自于：" + in_city, JLabel.RIGHT);
		l2.setBounds(655, 2, 300, 20);
		l2.setFont(labelFont);

		add(l1);
		add(l2);

		l_name = new JLabel("书籍名：", JLabel.LEFT);
		t_name = new JTextField();
		l_category = new JLabel("分类：", JLabel.RIGHT);
		c_category = new JComboBox<String>();
		c_category.addItem("工具类");
		c_category.addItem("小说类");
		b_query = new JButton("查询");

		l_name.setFont(labelFont);
		t_name.setFont(labelFont);
		l_category.setFont(labelFont);
		c_category.setFont(labelFont);
		b_query.setFont(labelFont);

		l_name.setBounds(2, 30, 600, 25);
		t_name.setBounds(70, 30, 170, 25);
		l_category.setBounds(675, 30, 80, 25);
		c_category.setBounds(755, 30, 150, 25);
		b_query.setBounds(270, 30, 100, 25);

		b_query.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String tname=t_name.getText();
				System.out.println(tname);
				BookDb bdb=new BookDb();
				int search=bdb.Search(tname);
				if(search==2){
					JOptionPane.showMessageDialog(null, "图书在馆，可借！");
				}else if(search==1){
					JOptionPane.showMessageDialog(null, "图书全部借出！");
				}else if(search==0){
					JOptionPane.showMessageDialog(null, "图书馆中没有此图书！");
				}else {
					JOptionPane.showMessageDialog(null, "系统错误！");
				}
			}
		});

		add(l_name);
		add(t_name);
		add(l_category);
		add(c_category);
		add(b_query);

		// 书籍信息
		Object[] title = {"编号", "书名", "作者", "定价", "库存"};

		BookDb bd = new BookDb();
		List<Book> book_List = bd.getAllBooks();
		int size = book_List.size();
		Object[][] bookList = new Object[size][5];

		int i = 0;
		for (Book book : book_List) {
			System.out.println(book.getId() + " " + book.getName() + " " + book.getAuthor() + " " + book.getPrice() + " " + book.getNumber());
			bookList[i][0] = book.getId();
			bookList[i][1] = book.getName();
			bookList[i][2] = book.getAuthor();
			bookList[i][3] = Double.valueOf(book.getPrice()); // 显式转换为 Double
			bookList[i][4] = book.getNumber();
			i++;
		}

		table_book = new JTable(bookList, title);
		JScrollPane pane = new JScrollPane(table_book);
		pane.setBounds(2, 65, 960, 500);

		add(pane);
	}
}