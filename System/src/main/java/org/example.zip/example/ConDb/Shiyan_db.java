package org.example.ConDb;

import org.example.Other_class.Shiyan_class;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Shiyan_db {
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/EXPERIMENT";
    private static final String USER = "root";
    private static final String PASSWORD = "q3231423581";
    private List<Shiyan_class> shiyan_list=new ArrayList<>();

    public Shiyan_db() {
        con();
    }

    private void con() {
        Connection connection = null;


        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM test;";
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                String title=resultSet.getString("title");
                String start_time=resultSet.getString("start_time");
                String end_time=resultSet.getString("end_time");
                String id=resultSet.getString("id_test");
                String tid=resultSet.getString("tid");
                Shiyan_class s=new Shiyan_class(id,title,start_time,end_time,tid);
                shiyan_list.add(s);
            }


        } catch (ClassNotFoundException e) {
            System.out.println("JDBC驱动未找到: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("数据库连接失败: " + e.getMessage());
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                    System.out.println("数据库连接已关闭。");
                }
            } catch (SQLException e) {
                System.out.println("关闭连接时出错: " + e.getMessage());
            }
        }
    }

    public List<Shiyan_class> getShiyan_list() {
        return shiyan_list;
    }

    public static void main(String[] args) {
        Shiyan_db s=new Shiyan_db();
        System.out.println(s.getShiyan_list());
        for(Shiyan_class k:s.getShiyan_list()){
            System.out.println(k.getId());
//            System.out.println(k.getTeacher());
        }
    }
}
