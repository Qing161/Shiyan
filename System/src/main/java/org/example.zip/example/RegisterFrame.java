package org.example;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class RegisterFrame extends JFrame{
	JLabel l_id, l_name, l_password1, l_password2, l_type, l_sex, l_city;
	JTextField t_id, t_name;
	JPasswordField p_password1, p_password2;
	JComboBox<String> c_type;
	ButtonGroup gp;
	JRadioButton r_male, r_female;
	JComboBox<String> c_city;
	JButton b_reset, b_register;

	Font labelFont = new Font("仿宋", Font.PLAIN, 20);
	Font textFieldFont = new Font("仿宋", Font.PLAIN, 18);
	Font buttonFont = new Font("仿宋", Font.BOLD, 20);
	
	
    public RegisterFrame() {
    	this.setSize(400, 500);
    	this.setTitle("电商购物平台-注册页面");
    	this.setLocation(800, 200);
    	init();
    	this.setVisible(true);
    }
    
    public void init(){
    	l_id = new JLabel("账号：",JLabel.RIGHT);
    	l_name = new JLabel("姓名：",JLabel.RIGHT);		
		l_password1 = new JLabel("密码：",JLabel.RIGHT);
		l_password2 = new JLabel("确认密码：",JLabel.RIGHT);
		l_type = new JLabel("用户类型：",JLabel.RIGHT);
		l_sex = new JLabel("性别：",JLabel.RIGHT);
		l_city = new JLabel("城市：",JLabel.RIGHT);

		l_id.setFont(labelFont);
		l_name.setFont(labelFont);
		l_password1.setFont(labelFont);
		l_password2.setFont(labelFont);
		l_type.setFont(labelFont);
		l_sex.setFont(labelFont);
		l_city.setFont(labelFont);
		
		t_id = new JTextField();
		t_name = new JTextField();
		p_password1 = new JPasswordField();
		p_password2 = new JPasswordField();
		c_type = new JComboBox<String>();
		c_type.addItem("管理员");
		c_type.addItem("普通用户");
		c_type.setFont(labelFont);
		gp = new ButtonGroup();

		r_male = new JRadioButton("男");
		r_female = new JRadioButton("女");
		r_male.setFont(labelFont);
		r_female.setFont(labelFont);

		gp.add(r_male);
		gp.add(r_female);
		c_city = new JComboBox<String>();
		c_city.addItem("太原");//具体城市不作强制要求
		c_city.addItem("北京");
		c_city.addItem("天津");
		c_city.addItem("上海");
		c_city.addItem("广州");
		c_city.setFont(labelFont);
		b_reset = new JButton("重置");
		b_register = new JButton("注册");

		b_reset.setFont(buttonFont);
		b_register.setFont(buttonFont);
		
		b_register.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String id = t_id.getText();
				String name = t_name.getText();
				String password = null;
				String password1 = new String(p_password1.getPassword());
				String password2 = new String(p_password2.getPassword());
				
				String type = (String)c_type.getSelectedItem(); 
				char sex;
				if(r_male.isSelected()) {
					sex = '男';
				}else {
					sex = '女';
				}
				
				String city =(String)c_city.getSelectedItem();
				if(password1.length()<6){
					JOptionPane.showMessageDialog(null, "密码至少6位数！");
				} else if(password1.equals(password2)) {
					password = password1;
					User u = new User(id,name,password,type,sex,city);
					UserDb a=new UserDb();
					System.out.println(id+name+password);
					if(id.isEmpty()||name.isEmpty()||password.isEmpty()){
						JOptionPane.showMessageDialog(null, "请输入完整信息！");
					}else {
						a.add(id,name,password,type,sex,city);
						JOptionPane.showMessageDialog(null, "注册成功！");
						dispose();
						new UserInfoFrame(u);
					}
				}else {
					JOptionPane.showMessageDialog(null, "您两次输入的密码不一致，请从新输入！");
				}
			}
		});
		
		this.setLayout(new GridLayout(8,2,5,5));
		add(l_id);
		add(t_id);
		add(l_name);
		add(t_name);
		add(l_password1);
		add(p_password1);
		add(l_password2);
		add(p_password2);
		add(l_type);
		add(c_type);
		
		JPanel p = new JPanel();
		p.setLayout(new GridLayout(1, 2, 5, 5));
		p.add(r_male);
		p.add(r_female);
		add(l_sex);
		add(p);
		
		add(l_city);
		add(c_city);
		
		add(b_reset);
		add(b_register);
    }
}
